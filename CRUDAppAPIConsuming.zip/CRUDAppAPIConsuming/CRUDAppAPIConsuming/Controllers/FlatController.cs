﻿using CRUDAppAPIConsuming.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace CRUDAppAPIConsuming.Controllers
{
    public class FlatController : Controller
    {
        private string url = "https://localhost:7264/api/Flat/";
        private HttpClient client = new HttpClient();

        [HttpGet]
        public IActionResult Index(Society scty)
        {
            HttpResponseMessage response = client.GetAsync(url).Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                var content = JsonConvert.DeserializeObject<List<Society>>(data);
                return View(content);
            }
            return View(new List<Society>());
        }


        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Society st)
        {
            var data = JsonConvert.SerializeObject(st);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                TempData["AddMsg"] = "Flat Added...";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            //Society s1 = new Society();
            HttpResponseMessage response = client.GetAsync(url + id).Result;
            if (response.IsSuccessStatusCode)
            {
                var dt = response.Content.ReadAsStringAsync().Result;
                var content = JsonConvert.DeserializeObject<Society>(dt);
                //if (content != null)
                //{
                //    s1 = content;
                //}
                //return View(s1);
                return View(content);
            }
            return View();
        }

        [HttpPost]
        public IActionResult Edit(Society st)
        {
            var data = JsonConvert.SerializeObject(st);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage msg = client.PutAsync(url, content).Result;
            if (msg.IsSuccessStatusCode)
            {
                TempData["UpdMsg"] = "Flat Details Updated...";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Delete(string id)
        {
            HttpResponseMessage response = client.GetAsync(url + id).Result;
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                var content = JsonConvert.DeserializeObject<Society>(data);
                return View(content);
            }
            return View();
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult Deleted(string id)
        {
            HttpResponseMessage response = client.DeleteAsync(url + id).Result;
            if(response.IsSuccessStatusCode)
            {
                TempData["DelMsg"] = "Flat Deleted...";
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
