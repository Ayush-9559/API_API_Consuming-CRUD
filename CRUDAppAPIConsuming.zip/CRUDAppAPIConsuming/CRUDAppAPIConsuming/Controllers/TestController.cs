﻿using CRUDAppAPIConsuming.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace CRUDAppAPIConsuming.Controllers
{
    public class TestController : Controller
    {
        private string url = "https://localhost:7264/api/Test/";
        private HttpClient client = new HttpClient();


        [HttpGet]
        public async Task<IActionResult> Index(Class c)
        {
            HttpResponseMessage response = await client.GetAsync(url);
            if(response.IsSuccessStatusCode)
            {
                var data = await response.Content.ReadAsStringAsync();
                var content = JsonConvert.DeserializeObject<List<Class>>(data);
                return View(content);
            }
            return View(new List<Class>());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Class c)
        {
            var data = JsonConvert.SerializeObject(c);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage response = await client.PostAsync(url, content);
            if(response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "New Details Added..";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            Class cl = new Class();
            HttpResponseMessage response = await client.GetAsync(url + id);
            if(response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                var content = JsonConvert.DeserializeObject<Class>(data);
                if(content != null)
                {
                    cl = content;
                }
                return View(cl);
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Class cl)
        {
            var data = JsonConvert.SerializeObject(cl);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage response = await client.PutAsync(url + cl.id, content);
            if(response.IsSuccessStatusCode)
            {
                TempData["UpdateMessage"] = "Details Updated...";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            Class cl = new Class();
            HttpResponseMessage message = await client.GetAsync(url + id);
            if(message.IsSuccessStatusCode)
            {
                var data = await message.Content.ReadAsStringAsync();
                var content = JsonConvert.DeserializeObject<Class>(data);
                if(content != null)
                {
                    cl = content;
                }
                return View(cl);
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            Class cl = new Class();
            HttpResponseMessage response = await client.GetAsync(url + id);
            if (response.IsSuccessStatusCode)
            {
                var data = response.Content.ReadAsStringAsync().Result;
                var content = JsonConvert.DeserializeObject<Class>(data);
                if(content != null)
                {
                    cl = content;
                }
                return View(content);
            }
            return View();
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteDetails(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync(url + id);
            if(response.IsSuccessStatusCode)
            {
                TempData["DeleteMessage"] = "Details Deleted...";
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
