﻿using CRUDAppAPIConsuming.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Text.Json.Serialization;

namespace CRUDAppAPIConsuming.Controllers
{
    public class ClassController : Controller
    {
        private string baseURL = "https://localhost:7264/api/Class/";
        private HttpClient httpClient = new HttpClient();


        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var response = await httpClient.GetAsync(baseURL);
            if (response.IsSuccessStatusCode)
            {
                var jsonData = await response.Content.ReadAsStringAsync();
                var classes = JsonConvert.DeserializeObject<List<Student>>(jsonData);
                return View(classes);
            }
            return View(new List<Student>());
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        
        [HttpPost]
        public async Task<IActionResult> Create(Student std)
        {
            string data = JsonConvert.SerializeObject(std);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage message = await httpClient.PostAsync(baseURL, content);
            if (message.IsSuccessStatusCode)
            {
                TempData["Message"] = "Student Added Succesfully.";
                return RedirectToAction("Index");
            }
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            Student std = new Student();
            HttpResponseMessage response = await httpClient.GetAsync(baseURL + id);
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Student>(result);
                if (data != null)
                {
                    std = data;
                }
                return View(data);
            }
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Edit(Student std)
        {
            string data = JsonConvert.SerializeObject(std);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage message = await httpClient.PutAsync(baseURL + std.stdId, content);
            if (message.IsSuccessStatusCode)
            {
                TempData["Update_Message"] = "Student Added Succesfully.";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            Student std = new Student();
            HttpResponseMessage response = await httpClient.GetAsync(baseURL + id);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Student>(result);
                if (data != null)
                {
                    std = data;
                }
                return View(std);
            }
            return View();
        }



        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            Student std = new Student();
            HttpResponseMessage response = await httpClient.GetAsync(baseURL + id);
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Student>(result);
                if (data != null)
                {
                    std = data;
                }
            }
            return View(std);
        }


        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            HttpResponseMessage message = httpClient.DeleteAsync(baseURL + id).Result;
            if (message.IsSuccessStatusCode)
            {
                TempData["Delete_Message"] = "Student Details Deleted Succesfully.";
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
