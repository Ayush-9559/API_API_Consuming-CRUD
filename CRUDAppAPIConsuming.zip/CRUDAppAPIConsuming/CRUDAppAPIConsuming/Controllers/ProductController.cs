﻿using CRUDAppAPIConsuming.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace CRUDAppAPIConsuming.Controllers
{
    public class ProductController : Controller
    {
        private string url = "https://localhost:7264/api/Products/";
        private HttpClient httpClient = new HttpClient();

        [HttpGet]
        public IActionResult Index()
        {
            HttpResponseMessage response = httpClient.GetAsync(url).Result;
            if(response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<List<Product>>(result);
                return View(data);
            }
            return View(new List<Product>());
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product p)
        {
            string data = JsonConvert.SerializeObject(p);
            StringContent result = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage content = await httpClient.PostAsync(url, result);
            if(content.IsSuccessStatusCode)
            {
                TempData["Message"] = "Product Added Successfully...";
                return RedirectToAction("Index", "Product");
            }
            return View();
        }


        [HttpGet]
        public async Task <IActionResult> Update(int id)
        {
            Product pt = new Product();
            HttpResponseMessage response = await httpClient.GetAsync(url + id);
            if(response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var content = JsonConvert.DeserializeObject<Product>(result);
                if(content != null)
                {
                    pt = content;
                }
                return View(content);
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Update(Product p)
        {
            string data = JsonConvert.SerializeObject(p);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage message = await httpClient.PutAsync(url + p.id, content);
            if (message.IsSuccessStatusCode)
            {
                TempData["UpdateMessage"] = "Product Details Updated...";
                return RedirectToAction("Index", "Product");
            }
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            Product std = new Product();
            HttpResponseMessage response = await httpClient.GetAsync(url + id);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Product>(result);
                if (data != null)
                {
                    std = data;
                }
                return View(std);
            }
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            Product getdt = new Product();
            HttpResponseMessage message = await httpClient.GetAsync(url + id);
            if(message.IsSuccessStatusCode)
            {
                string content = message.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<Product>(content);
                if(result != null)
                {
                    getdt = result;
                }
                return View(result);
            }
            return View();
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteDt(Product p)
        {
            HttpResponseMessage response = await httpClient.DeleteAsync(url + p.id);
            if (response.IsSuccessStatusCode)
            {
                TempData["DeleteMessage"] = "Product Deleted...";
                return RedirectToAction("Index", "Product");
            }
            return View();
        }

    }
}
