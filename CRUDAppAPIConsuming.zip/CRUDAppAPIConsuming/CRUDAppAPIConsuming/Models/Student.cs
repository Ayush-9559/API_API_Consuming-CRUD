﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAppAPIConsuming.Models
{
    //public class Student
    //{
    //    public int stdId { get; set; }
    //    [Required]
    //    public string stdname { get; set; }
    //    [Required]
    //    public int stdrollno { get; set; }
    //    [Required]
    //    public string stdstream { get; set; }
    //        [Required]
    //    public string stdaddsubjects { get; set; }
    //    [Required]
    //    public string fees { get; set; }


    //}





}
