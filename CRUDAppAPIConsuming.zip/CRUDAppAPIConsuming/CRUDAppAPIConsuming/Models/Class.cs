﻿namespace CRUDAppAPIConsuming.Models
{

    public class Class
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string givenName { get; set; }
    }

}
