﻿namespace CRUDAppAPIConsuming.Models
{
    public class Society
    {
        public int id { get; set; }
        public string wingName { get; set; }
        public int floorNo { get; set; }
        public int flatNo { get; set; }
        public string flatType { get; set; }
    }

}
