﻿using API_Practice.Models;
using Microsoft.EntityFrameworkCore;

namespace API_Practice.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Product> Products { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Test>  Tests { get; set; }
        public DbSet<Society> Societies {  get; set; } 
    }
}
