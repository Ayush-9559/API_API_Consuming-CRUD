﻿namespace API_Practice.Models
{
    public class Society
    {
        public int Id {  get; set; }
        public string WingName { get; set; }
        public int FloorNo { get; set; }
        public int FlatNo { get; set; }
        public string FlatType { get; set; }


    }
}
