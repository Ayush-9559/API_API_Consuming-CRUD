﻿using System.ComponentModel.DataAnnotations;

namespace API_Practice.Models
{
    public class Class
    {
        [Key]
        public int stdId { get; set; }
        public string stdname { get; set; }
        public int stdrollno { get; set; }
        public string stdstream { get; set; }
        public string stdaddsubjects { get; set; }
        public string fees { get; set; }  

    }
}
