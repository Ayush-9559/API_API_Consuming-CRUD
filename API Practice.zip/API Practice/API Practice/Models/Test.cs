﻿namespace API_Practice.Models
{
    public class Test
    {
        public int Id { get; set; }
        public string Username { get; set; }

        public string Password { get; set; }
        public string GivenName { get; set; }
    }
}
