﻿using API_Practice.Data;
using API_Practice.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_Practice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly ApplicationDbContext db;
        public TestController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult GetAllDetails()
        {
            var data = db.Tests.ToList();
            return Ok(data);
        }

        [HttpPost]
        public IActionResult AddDetails(Test p)
        {
            var data = db.Tests.Add(p);
            db.SaveChanges();
            return Ok("Identity Added Successfully");
        }


        [HttpPut("{id}")]
        public IActionResult UpdateDetails(int id, Test p)
        {
            var data = db.Tests.Find(id);
            data.Username = p.Username;
            data.Password = p.Password;
            data.GivenName = p.GivenName;
            db.SaveChanges();
            return Ok("Identity Updated successfully");
        }

        [Route("{id}")]
        [HttpGet]
        public IActionResult FindDetailById(int id)
        {
            var data = db.Tests.Find(id);
            return Ok(data);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDetails(int id)
        {
            var data = db.Tests.Find(id);
            db.Tests.Remove(data);
            db.SaveChanges();
            return Ok("Identity Deleted Successfully");
        }
    }
}
