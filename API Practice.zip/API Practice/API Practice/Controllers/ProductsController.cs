﻿using API_Practice.Data;
using API_Practice.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_Practice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ApplicationDbContext db;
        public ProductsController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult GetAllProductsDetails()
        {
            var data = db.Products.ToList();
            return Ok(data);
        }

        [HttpPost]
        public IActionResult AddProduct(Product p)
        {
            var data = db.Products.Add(p);
            db.SaveChanges();
            return Ok("Product Added Successfully");
        }


        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id, Product p)
        {
            var data = db.Products.Find(id);
            data.Name = p.Name;
            data.Description = p.Description;
            data.Category = p.Category;
            data.Price = p.Price;
            db.SaveChanges();
            return Ok("Details Updated successfully");
        }

        [Route("{id}")]
        [HttpGet]
        public IActionResult FindProductById(int id)
        {
            var data = db.Products.Find(id);
            return Ok(data);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var data = db.Products.Find(id);
            db.Products.Remove(data);
            db.SaveChanges();
            return Ok("Product Deleted Successfully");
        }
    }
}
