﻿using API_Practice.Data;
using API_Practice.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_Practice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClassController : ControllerBase
    {
        private readonly ApplicationDbContext db;

        public ClassController (ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var data = db.Classes.ToList();
            return Ok(data);
        }


        [HttpGet("{id}")]
        public IActionResult GetDetailsById(int id)
        {
            var fetchById = db.Classes.Find(id);
            return Ok(fetchById);
        }

        [HttpPost]
        public IActionResult AddDetails(Class cl)
        {
            var data = db.Classes.Add(cl);
            db.SaveChanges();
            return Ok("Student Details Added");
        }

        [HttpPut("{id}")]
        public IActionResult UpdateDetails(Class cls)
        {
            var data = db.Classes.Find(cls.stdId);
            if (data != null)
            {
                data.stdname = cls.stdname;
                data.stdrollno = cls.stdrollno;
                data.stdstream = cls.stdstream;
                data.stdaddsubjects = cls.stdaddsubjects;
                data.fees = cls.fees;

                db.SaveChanges();
            }
            return Ok("Details Updated");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Class delDetails = db.Classes.Find(id);
            db.Classes.Remove(delDetails);
            db.SaveChanges();
            return Ok("Details Deleted");
        }
    }
}
