﻿using API_Practice.Data;
using API_Practice.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API_Practice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlatController : ControllerBase
    {
        private readonly ApplicationDbContext db;
        public FlatController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public async Task<IActionResult> AllFlats()
        {
            var allflats = await db.Societies.ToListAsync();
            return Ok(allflats);
        }


        [HttpPost]
        public async Task<IActionResult> AddFlats(Society scty)
        {
            var data = new Society();
            {
                data.WingName = scty.WingName;
                data.FloorNo = scty.FloorNo;
                data.FlatNo = scty.FlatNo;
                data.FlatType = scty.FlatType;
            }
            await db.Societies.AddAsync(data);
            await db.SaveChangesAsync();
            return Ok("Flats Added Succesfully");
        }



        [HttpGet("{id}")]
        public async Task<IActionResult> getflatsByid(int id)
        {
            var getflatsByid = await db.Societies.FindAsync(id);
            return Ok(getflatsByid);
        }



        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFlats(Society scty, int id)
        {
            var getflat = await db.Societies.FindAsync(id);
            if (getflat != null)
            {
                getflat.WingName = scty.WingName;
                getflat.FloorNo = scty.FloorNo;
                getflat.FlatNo = scty.FlatNo;
                getflat.FlatType = scty.FlatType;
                await db.SaveChangesAsync();
            }
            return Ok("Details Updated...");
        }



        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFlats(int id)
        {
            var delflat = await db.Societies.FindAsync(id);
            if(delflat != null)
            {
                db.Remove(delflat);
                await db.SaveChangesAsync();
                return Ok("Details Deleted...");
            }
            return Ok("Could not find any flats based on the provided id");
        }
    }
}
